$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "337"
$LUT = "819"
$FF = "828"
$DSP = "11"
$BRAM ="0"
$SRL ="82"
#=== Final timing ===
$TargetCP = "8.000"
$CP = "7.584"
